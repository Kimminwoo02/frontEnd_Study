const select = document.querySelector('#select');
      select.addEventListener('change', ()=>{
          location.href = select.value; 
          // <a href="index.html"> </a>
})